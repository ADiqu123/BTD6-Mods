# Zap-Monkey-Mod-BTD6
Zap Monkey is a custom tower for Bloons TD 6. 
Art and upgrade ideas comes from https://www.reddit.com/r/btd6/comments/mxjj42/tower_idea_zap_monkey/. I did make some changes to the upgrades.
You can do whatever you want with the code.
Download both ZapMonkey.dll files and ZapMonkey.pdp then put them in your btd6 mods folder. This mod REQUIRES BTD6 Mod Helper to work. Like with all mods you need to have Melon Loader. After you have both files and BTD6 Mod Helper in the mods folder all you have to do is restart your game and the mod should load!
